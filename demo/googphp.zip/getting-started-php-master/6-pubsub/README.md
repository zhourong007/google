# 6 - Using Pub/Sub

This folder contains the sample code for the [Using Pub/Sub][step-6]
tutorial. Please refer to the tutorial for instructions on configuring, running,
and deploying this sample.

[step-6]: https://cloud.google.com/php/getting-started/using-pub-sub

