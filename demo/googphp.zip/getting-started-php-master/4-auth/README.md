# 4 - Authenticating users

This folder contains the sample code for the [Authenticating users][step-4]
tutorial. Please refer to the tutorial for instructions on configuring, running,
and deploying this sample.

[step-4]: https://cloud.google.com/php/getting-started/authenticate-users

